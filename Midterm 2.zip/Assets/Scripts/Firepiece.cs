using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Firepiece : MonoBehaviour
{
    private bool selected = false;
    private Vector3 selectedPos;
    private Rigidbody rb;
    public float forceMultiplier = 10f;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnMouseDown()
    {
        if (!selected)
        {
            selected = true;
            selectedPos = Input.mousePosition;
        }
        else
        {
            selected = false;
            Vector3 targetPos = Input.mousePosition;
            Vector3 direction = (targetPos - selectedPos).normalized;
            float force = (targetPos - selectedPos).magnitude * forceMultiplier;
            rb.AddForce(direction * force);
            Debug.Log(direction);
        }

    }

  
}
