using UnityEngine;

public class SpawnManager : MonoBehaviour
{

    public GameObject[] prefabs; //array of prefabs to be spawned later

    //spawn settings
    public Transform spawnpoint; // spawn location
    public float spacing = 15f; // distance between prefabs
    public float interval = 2f; // time between spawns
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        InvokeRepeating(nameof(SpawnPrefabRow), 0f, interval);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void SpawnPrefabRow()
    {
        //spawn three prefabs in a row
        for (int i = 0; i < 3; i++)
        {
            //choose random prefab
            int randomIndex = Random.Range(0, prefabs.Length);
            GameObject prefabToSpawn = prefabs[randomIndex];

            

            //calculate position for prefab within row
            Vector3 spawnPosition = spawnpoint.position + new Vector3(i * spacing, 0, 0);

            //instantiate Prefab
            Instantiate(prefabToSpawn, spawnPosition, spawnpoint.rotation);

            
        }
    }
}
