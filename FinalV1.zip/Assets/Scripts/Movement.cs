using UnityEngine;



public class Movement : MonoBehaviour
{

    public float movementValue = 1.5f;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        inputs();
    }
    private void FixedUpdate()
    {
        

       
    }
    void inputs()
    {
        if (transform.position.x > -1.5f)
        {
            if (Input.GetKeyDown(KeyCode.A))
            {
                transform.position = new Vector3(transform.position.x - movementValue, transform.position.y, transform.position.z);
            }
        }
        if (transform.position.x < 1.5f)
        {
            if (Input.GetKeyDown(KeyCode.D))
            {
                transform.position = new Vector3(transform.position.x + movementValue, transform.position.y, transform.position.z);
            }
        }
    }
}
