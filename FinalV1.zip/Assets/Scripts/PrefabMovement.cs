using UnityEngine;

public class PrefabMovement : MonoBehaviour
{

    public Rigidbody rb;
    float moveForce = 2f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        //rb.AddForce(Vector3.up * moveForce * 100 * Time.deltaTime, ForceMode.Impulse);
    }
}
